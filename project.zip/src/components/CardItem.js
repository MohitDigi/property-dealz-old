import React from "react";
import { Card } from "antd";
import { Data } from "../properties";
import styled from "styled-components";
import hotel from "../images/hotel.png";
import location from "../images/location.svg";
import bed from "../images/bed-icon.svg";
import square from "../images/square-icon.svg";
import tub from "../images/shover-icon.svg";
console.log(Data);

const CardItem = () => {
  return (
    <>
      <div style={{ overflowY: "scroll", height: "1100px", width: "100%" }}>
        {Data.map((item) => {
          return (
            <Card
              hoverable
              style={{
                display: "flex",
              }}
              cover={
                <img
                  alt="example"
                  src={hotel}
                  style={{
                    padding: "20px",
                    width: "200px",
                    marginTop: "18px",
                    marginRight: "-20px",
                  }}
                />
              }
            >
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div>
                  <h2>
                    {item.name}
                    <span
                      style={{
                        fontSize: "14px",
                        fontWeight: "initial",
                        marginLeft: "20px",
                      }}
                    >
                      {item.type}
                    </span>
                  </h2>
                </div>
                <div className="location" style={{ display: "flex" }}>
                  <img
                    alt="location-icon"
                    src={location}
                    style={{
                      height: "20px",
                      marginRight: "10px",
                    }}
                  />
                  <p style={{ marginTop: "0px" }}>{item.location}</p>
                </div>
                <div
                  className="description"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginTop: "-14px",
                  }}
                >
                  <img alt="bedrooms" src={bed} />
                  <StyledP>{item.beds}</StyledP>
                  <img alt="tub" src={tub} />
                  <StyledP>{item.baths}</StyledP>
                  <img alt="square" src={square} />
                  <StyledP>{item.area} sq meters</StyledP>
                  
                  <h2 style={{ marginLeft: "200px" }}>₹{item.price}</h2>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
};
const StyledP = styled.p`
  margin-right: 14px;
`;

export default CardItem;
